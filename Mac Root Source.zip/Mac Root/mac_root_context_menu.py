#!/usr/bin/env python3
"""
Mac Root Context Menu Installer
Death's Head Software

Adds a "Run as Root" option to the macOS Finder right-click menu
via a Quick Action (Services menu). Works on Apple Silicon and Intel.

Uses the native macOS password dialog — no Terminal window appears.

Usage:
    python3 mac_root_context_menu.py install    # Install the Quick Action
    python3 mac_root_context_menu.py uninstall  # Remove the Quick Action
"""

import os
import sys
import subprocess
import shutil

SERVICE_NAME = "Run as Root"
WORKFLOW_DIR = os.path.expanduser(
    f"~/Library/Services/{SERVICE_NAME}.workflow"
)
CONTENTS_DIR = os.path.join(WORKFLOW_DIR, "Contents")
HELPER_PATH = os.path.expanduser("~/.local/bin/run_as_root_helper.py")

# Standalone Python helper that does the actual work.
# Uses osascript "with administrator privileges" which triggers the
# native macOS password dialog — no Terminal window at all.
HELPER_SCRIPT = '''\
#!/usr/bin/env python3
"""
Run as Root Helper — Death's Head Software
Uses macOS native password dialog (no Terminal window).
"""
import subprocess, sys, os, shlex

# Capture the real user's environment before elevation changes it.
# osascript "with administrator privileges" runs as root with HOME=/var/root,
# so we bake the real user's env into the command.
real_user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
real_home = os.path.expanduser("~")

for filepath in sys.argv[1:]:
    # Determine what to execute
    if filepath.endswith(".app"):
        # Run the actual binary inside the .app bundle so it
        # truly executes as root (open drops privileges).
        bundle_name = os.path.basename(filepath).rsplit(".app", 1)[0]
        macos_dir = os.path.join(filepath, "Contents", "MacOS")
        binary = os.path.join(macos_dir, bundle_name)
        if not os.path.isfile(binary):
            try:
                entries = os.listdir(macos_dir)
                binary = os.path.join(macos_dir, entries[0]) if entries else filepath
            except OSError:
                binary = filepath
        cmd = shlex.quote(binary)
    elif filepath.endswith(".py"):
        cmd = "/usr/bin/python3 " + shlex.quote(filepath)
    elif filepath.endswith(".sh"):
        cmd = "/bin/bash " + shlex.quote(filepath)
    elif os.access(filepath, os.X_OK):
        cmd = shlex.quote(filepath)
    else:
        cmd = "open " + shlex.quote(filepath)

    # Prepend env vars so the elevated process keeps the real
    # user's HOME, USER, and cache paths — matching sudo -E.
    env_prefix = (
        "export HOME=" + shlex.quote(real_home) + "; "
        "export USER=" + shlex.quote(real_user) + "; "
        "export LOGNAME=" + shlex.quote(real_user) + "; "
        "export PIP_CACHE_DIR=" + shlex.quote(real_home + "/.cache/pip") + "; "
    )
    full_cmd = env_prefix + cmd

    # Escape for AppleScript string literal
    as_cmd = full_cmd.replace("\\\\", "\\\\\\\\").replace('"', '\\\\"')

    # "with administrator privileges" shows the native macOS
    # password dialog — no Terminal window involved.
    applescript = 'do shell script "' + as_cmd + '" with administrator privileges'
    subprocess.run(["/usr/bin/osascript", "-e", applescript])
'''

# The document.wflow XML with the critical workflowMetaData that tells
# Automator this Quick Action receives files/folders in Finder.
DOCUMENT_WFLOW_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>AMApplicationBuild</key>
	<string>523</string>
	<key>AMApplicationVersion</key>
	<string>2.10</string>
	<key>AMWorkflowSchemaVersion</key>
	<real>2</real>
	<key>actions</key>
	<array>
		<dict>
			<key>action</key>
			<dict>
				<key>AMAccepts</key>
				<dict>
					<key>Container</key>
					<string>List</string>
					<key>Optional</key>
					<true/>
					<key>Types</key>
					<array>
						<string>com.apple.cocoa.path</string>
					</array>
				</dict>
				<key>AMActionVersion</key>
				<string>2.0.3</string>
				<key>AMApplication</key>
				<array>
					<string>Automator</string>
				</array>
				<key>AMBundleIdentifier</key>
				<string>com.apple.RunShellScript-actionDescription</string>
				<key>AMName</key>
				<string>Run Shell Script</string>
				<key>AMProvides</key>
				<dict>
					<key>Container</key>
					<string>List</string>
					<key>Types</key>
					<array>
						<string>com.apple.cocoa.string</string>
					</array>
				</dict>
				<key>ActionBundlePath</key>
				<string>/System/Library/Automator/Run Shell Script.action</string>
				<key>ActionName</key>
				<string>Run Shell Script</string>
				<key>ActionParameters</key>
				<dict>
					<key>COMMAND_STRING</key>
					<string>""" + HELPER_PATH + """ "$@"</string>
					<key>CheckedForUserDefaultShell</key>
					<true/>
					<key>inputMethod</key>
					<integer>1</integer>
					<key>shell</key>
					<string>/bin/bash</string>
					<key>source</key>
					<string></string>
				</dict>
				<key>BundleIdentifier</key>
				<string>com.apple.Automator.RunShellScript</string>
				<key>CFBundleVersion</key>
				<string>2.0.3</string>
				<key>CanShowSelectedItemsWhenRun</key>
				<false/>
				<key>CanShowWhenRun</key>
				<true/>
				<key>Category</key>
				<array>
					<string>AMCategoryUtilities</string>
				</array>
				<key>Class Name</key>
				<string>RunShellScriptAction</string>
				<key>InputUUID</key>
				<string>A7E1E81D-83B1-4749-8726-000000000001</string>
				<key>Keywords</key>
				<array>
					<string>Shell</string>
					<string>Script</string>
					<string>Command</string>
					<string>Run</string>
				</array>
				<key>OutputUUID</key>
				<string>A7E1E81D-83B1-4749-8726-000000000002</string>
				<key>UUID</key>
				<string>A7E1E81D-83B1-4749-8726-000000000003</string>
				<key>UnlocalizedApplications</key>
				<array>
					<string>Automator</string>
				</array>
			</dict>
			<key>isViewVisible</key>
			<true/>
		</dict>
	</array>
	<key>connectors</key>
	<dict/>
	<key>workflowMetaData</key>
	<dict>
		<key>serviceInputTypeIdentifier</key>
		<string>com.apple.Automator.fileSystemObject</string>
		<key>serviceOutputTypeIdentifier</key>
		<string>com.apple.Automator.nothing</string>
		<key>serviceProcessesInput</key>
		<integer>0</integer>
		<key>workflowTypeIdentifier</key>
		<string>com.apple.Automator.servicesMenu</string>
	</dict>
</dict>
</plist>
"""

INFO_PLIST_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleName</key>
	<string>""" + SERVICE_NAME + """</string>
	<key>CFBundleIdentifier</key>
	<string>com.deathshead.runasroot</string>
	<key>CFBundleVersion</key>
	<string>1.0</string>
	<key>CFBundleShortVersionString</key>
	<string>1.0</string>
	<key>NSServices</key>
	<array>
		<dict>
			<key>NSMenuItem</key>
			<dict>
				<key>default</key>
				<string>""" + SERVICE_NAME + """</string>
			</dict>
			<key>NSMessage</key>
			<string>runWorkflowAsService</string>
			<key>NSSendFileTypes</key>
			<array>
				<string>public.item</string>
			</array>
		</dict>
	</array>
</dict>
</plist>
"""


def install():
    """Install the Quick Action workflow bundle and helper script."""
    if os.path.exists(WORKFLOW_DIR):
        print("Removing existing workflow...")
        shutil.rmtree(WORKFLOW_DIR)

    # Install the helper script
    os.makedirs(os.path.dirname(HELPER_PATH), exist_ok=True)
    with open(HELPER_PATH, "w") as f:
        f.write(HELPER_SCRIPT)
    os.chmod(HELPER_PATH, 0o755)
    print(f"Installed helper at {HELPER_PATH}")

    # Create workflow bundle
    os.makedirs(CONTENTS_DIR, exist_ok=True)

    wflow_path = os.path.join(CONTENTS_DIR, "document.wflow")
    with open(wflow_path, "w") as f:
        f.write(DOCUMENT_WFLOW_XML)

    info_path = os.path.join(CONTENTS_DIR, "Info.plist")
    with open(info_path, "w") as f:
        f.write(INFO_PLIST_XML)

    # Validate plists
    subprocess.run(["plutil", "-lint", wflow_path], capture_output=True)
    subprocess.run(["plutil", "-lint", info_path], capture_output=True)

    # Refresh services database
    subprocess.run(
        ["/System/Library/CoreServices/pbs", "-update"],
        capture_output=True,
    )

    print(f"\nInstalled '{SERVICE_NAME}' Quick Action.")
    print()
    print("IMPORTANT — open in Automator and save (Cmd+S) to register:")
    print()
    print("  open -a Automator ~/Library/Services/Run\\ as\\ Root.workflow")
    print()
    print("After saving, right-click any file in Finder >")
    print("Quick Actions > Run as Root")
    print()
    print("If it doesn't appear:")
    print("  System Settings > Privacy & Security > Extensions >")
    print("  Finder Extensions — enable 'Run as Root'")


def uninstall():
    """Remove the Quick Action and helper script."""
    removed = False
    if os.path.exists(WORKFLOW_DIR):
        shutil.rmtree(WORKFLOW_DIR)
        print(f"Removed '{SERVICE_NAME}' Quick Action.")
        removed = True
    if os.path.exists(HELPER_PATH):
        os.remove(HELPER_PATH)
        print(f"Removed helper at {HELPER_PATH}")
        removed = True
    if not removed:
        print(f"'{SERVICE_NAME}' is not installed.")
        return
    subprocess.run(
        ["/System/Library/CoreServices/pbs", "-update"],
        capture_output=True,
    )
    print("Services database refreshed.")


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("install", "uninstall"):
        print(__doc__.strip())
        sys.exit(1)

    if sys.argv[1] == "install":
        install()
    else:
        uninstall()


if __name__ == "__main__":
    main()
